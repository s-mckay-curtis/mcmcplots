## .htmlStartFile <- function(dir, filename, title, cssfile){
##     txt <- c('<html>', '<head>')
##     txt <- c(txt, paste('<title>', title, '</title>', sep=''))
##     txt <- c(txt, paste('<link rel=\"stylesheet\" type=text/css href=\"', cssfile, '\" />', sep=""))
##     txt <- c(txt, '<')
## }
